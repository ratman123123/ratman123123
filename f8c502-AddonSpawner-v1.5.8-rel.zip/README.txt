Requirements
============
GTA V (v1.0.877.1 or later)
ScriptHookV

Installation
============
Put AddonSpawner.asi and the AddonSpawner folder in the main GTA V folder.

Usage
=====
Press F5 to show the menu, or enter the "addonspawner" cheat.

Add image previews:
Put a png or jpg image inside AddonSpawner/img, with the file name being the
spawn name of the vehicle. Recommended: png, 480x270. Any other aspect ratio
also works. Try keeping the file small for better performance.

User DLC Instructions
=====================
In the folder AddonSpawner\UserDLC, create a `<Custom DLC Name>.list` file.
Make sure the extension is `.list`.
In this file, add the model names for vehicles that should be in this DLC.
For example, if you have Japanese car addons, create the following file:

JDM Cars.list

Inside the `.list` file, put each model you want on a new line, for example

nisgtr32
ae86

A `JDM Cars` entry will then appear in the main menu, which contains the
vehicles added. They can still be sorted by brand or class, giving you some
options to manage your add-on vehicle packs.


Changing hotkey
===============
Change MenuKey in settings_menu.ini to something else.
Refer to available keys in Keyboard_Keys.txt.

You can also assign a controller key combo to open the menu.
settings_menu.ini should contain all info you need.

Source
======
https://github.com/ikt32/GTAVAddonLoader

© ikt 2025. All rights reserved.
